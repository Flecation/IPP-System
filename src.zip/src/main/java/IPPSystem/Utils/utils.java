package IPPSystem.Utils;

import IPPSystem.Constants.enumDuration;
import IPPSystem.Constants.notificationType;
import IPPSystem.Models.projects;
import IPPSystem.Models.users;
import IPPSystem.Models.workItems;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import org.kordamp.ikonli.fontawesome6.FontAwesomeSolid;
import org.kordamp.ikonli.javafx.FontIcon;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;

//This is collected place for all utils
public class utils {

    private static Parent currentAlertRoot = null;

    private static durationHelper durationHelper = new durationHelper();

    //setting the tile bar of the exit,mini,restore buttons called from the tileBar class
    public static void setTitleBar(Parent basePane, Button minimizeBtn, Button restoreBtn, Button exitBtn) {
        titleBar.setTitleBar(basePane, minimizeBtn, restoreBtn, exitBtn);
    }

    //For setting the tool tip for any buttons
    public static void setToolTip(Button btn,String suggestion){
        Tooltip tooltip = new Tooltip(suggestion);
//            tooltip.setMaxSize(33,17);
        tooltip.setStyle("-fx-font-size:12px;");
        tooltip.setShowDelay(Duration.millis(300));
        Tooltip.install(btn,tooltip);
    }
    public static void setToolTip(Label lbl,String suggestion){
        Tooltip tooltip = new Tooltip(suggestion);
//            tooltip.setMaxSize(33,17);
        tooltip.setStyle("-fx-font-size:12px;");
        tooltip.setShowDelay(Duration.millis(300));
        Tooltip.install(lbl,tooltip);

    }

    //For setting the password field if in the needed place
    public static void setPasswordField(TextField showPasswordField, PasswordField hidePasswordField, CheckBox showPasswordCheckBox){

        showPasswordField.setVisible(false);
        hidePasswordField.setVisible(true);
        showPasswordCheckBox.setSelected(false);

        showPasswordCheckBox.setOnAction(event -> {
            if(showPasswordCheckBox.isSelected()){
                showPasswordField.setText(hidePasswordField.getText());
                hidePasswordField.setVisible(false);
                showPasswordField.setVisible(true);

            }else{
                hidePasswordField.setText(showPasswordField.getText());
                hidePasswordField.setVisible(true);
                showPasswordField.setVisible(false);
            }
        });


    }

    public static void setFloatTextFieldStyle(Label textLabel , TextField textField){
        new textFieldStyle().floatTextFieldStyle(textLabel,textField);
    }

    public static void setFloatPasswordFieldStyle(Label pwLabel, TextField showPwTxt , PasswordField hidePwTxt){
        new textFieldStyle().floatPasswordStyle(pwLabel,showPwTxt,hidePwTxt);
    }

    public static void setFocusAnimation(Region underline,String from, String to){
        Color From = Color.web(from);
        Color To = Color.web(to);
        focusAnimation.animateUnderline(underline,From,To);
    }



    private static Pane findOverlayTargetPane(Parent node) {
        if (node == null) {
            return null;
        }

        // Prefer the pane passed by the caller (e.g., login.fxml's overlayPane)
        if (node instanceof Pane pane) {
            return pane;
        }

        Node current = node;
        while (current != null) {
            if (current instanceof Pane pane) {
                return pane;
            }
            current = current.getParent();
        }

        if (node.getScene() != null && node.getScene().getRoot() instanceof Pane sceneRootPane) {
            return sceneRootPane;
        }
        return null;
    }

    public static void setTheme(Parent root){
        themeToggle.getInstance().setTheme(root,"/CSS/lightMode.css","/CSS/darkMode.css");
    }

    public static void changeTheme(){
        themeToggle.getInstance().toggleTheme();
    }

    public static String hashPassword(String password){
        return passwordCrafting.hashPassword(password);
    }

    public static boolean checkPassword(String inputPassword, String realPassword){
        return passwordCrafting.checkPassword(inputPassword,realPassword);
    }

    public static void switchNewScene(Button clickButton, String fxmlName){
        switchPage.switchScene(clickButton, fxmlName);
    }


    public static void openFxml(String fxml, StackPane loadPane){
        switchPage.getInstance(loadPane).openFxml(fxml);
    }

    public static void showProjectCards(ObservableList<projects> projects, VBox containerPane, StackPane loadPane){
        switchPage.getInstance(loadPane).loadProjects(projects, containerPane);
    }


    public static void openProjectDetails(projects project,StackPane a){
        switchPage.getInstance(a).openProjectDetails(project);
    }

    public static void openWorkItemDetails(workItems items,projects project, StackPane a){
        switchPage.getInstance(a).openWorkItemDetails(items,project);
    }

    public static void viewUserInfo(users user, StackPane loadPane){
        switchPage.getInstance(loadPane).viewUsersInfo(user);
    }

    public static Double durationFormat(Double duration, enumDuration durationStatus){return durationHelper.durationAssign(duration,durationStatus);}

    public static HashMap<enumDuration,Double> getDuration(Double duration){return durationHelper.showDuration(duration);}

    public static String generateProjectId(int projectId){
        String result = "PRJ-";
        if (projectId >99){
            result += projectId;
        }else if(projectId >9){
            result += "0"+projectId;
        }else {
            result += "00"+projectId;
        }
        return result;
    }

    public static void durationShowHelper(projects project,ComboBox<enumDuration> durationBox,TextField durationTxt){
        durationHelper.durationAssignHelper(project,durationBox,durationTxt);
    }

    public static String getOnlyOneDuration(Double duration,enumDuration durationType){
        if (durationType.equals(enumDuration.MONTH)) return durationHelper.showMonthDuration(duration);
        else if (durationType.equals(enumDuration.DAY)) return durationHelper.showDayDuration(duration);
        else return durationHelper.showYearDuration(duration);
    }

    public static String dateFormat(Date date){return dateFormatter.formatDate(date);}

    public static LocalDate toLocalDate(java.sql.Date date){return  dateFormatter.getLocalDate(date);}

    public static FontIcon iconSet(FontAwesomeSolid glyph){
        FontIcon icon = new FontIcon(glyph);
        icon.setIconSize(18);
        icon.getStyleClass().add("icon-Style");
        return icon;
    }
}
