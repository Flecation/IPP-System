package IPPSystem.Utils;

import IPPSystem.Constants.enumDuration;
import IPPSystem.Constants.notificationType;
import IPPSystem.Controllers.sideBarPaneController;
import IPPSystem.Interfaces.NavAware;
import IPPSystem.Models.projects;
import IPPSystem.Models.users;
import IPPSystem.Models.workItems;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import org.kordamp.ikonli.fontawesome6.FontAwesomeSolid;
import org.kordamp.ikonli.javafx.FontIcon;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.HashMap;

//This is collected place for all utils
public class utils {

    private static Parent currentAlertRoot = null;

    private static durationHelper durationHelper = new durationHelper();

    //setting the tile bar of the exit,mini,restore buttons called from the tileBar class
    public static void setTitleBar(Parent basePane, Button minimizeBtn, Button restoreBtn, Button exitBtn) {
        titleBar.setTitleBar(basePane, minimizeBtn, restoreBtn, exitBtn);
    }

    //For setting the tool tip for any buttons
    public static void setToolTip(Button btn,String suggestion){
        Tooltip tooltip = new Tooltip(suggestion);
//            tooltip.setMaxSize(33,17);
        tooltip.setStyle("-fx-font-size:12px;");
        tooltip.setShowDelay(Duration.millis(300));
        Tooltip.install(btn,tooltip);
    }
    public static void setToolTip(Label lbl,String suggestion){
        Tooltip tooltip = new Tooltip(suggestion);
//            tooltip.setMaxSize(33,17);
        tooltip.setStyle("-fx-font-size:12px;");
        tooltip.setShowDelay(Duration.millis(300));
        Tooltip.install(lbl,tooltip);

    }

    //For setting the password field if in the needed place
    public static void setPasswordField(TextField showPasswordField, PasswordField hidePasswordField, CheckBox showPasswordCheckBox){

        showPasswordField.setVisible(false);
        hidePasswordField.setVisible(true);
        showPasswordCheckBox.setSelected(false);

        showPasswordCheckBox.setOnAction(event -> {
            if(showPasswordCheckBox.isSelected()){
                showPasswordField.setText(hidePasswordField.getText());
                hidePasswordField.setVisible(false);
                showPasswordField.setVisible(true);

            }else{
                hidePasswordField.setText(showPasswordField.getText());
                hidePasswordField.setVisible(true);
                showPasswordField.setVisible(false);
            }
        });


    }

    public static void setFloatTextFieldStyle(Label textLabel , TextField textField){
        new textFieldStyle().floatTextFieldStyle(textLabel,textField);
    }

    public static void setFloatPasswordFieldStyle(Label pwLabel, TextField showPwTxt , PasswordField hidePwTxt){
        new textFieldStyle().floatPasswordStyle(pwLabel,showPwTxt,hidePwTxt);
    }

    public static void setFocusAnimation(Region underline,String from, String to){
        Color From = Color.web(from);
        Color To = Color.web(to);
        focusAnimation.animateUnderline(underline,From,To);
    }



    private static Pane findOverlayTargetPane(Parent node) {
        if (node == null) {
            return null;
        }

        // Prefer the pane passed by the caller (e.g., login.fxml's overlayPane)
        if (node instanceof Pane pane) {
            return pane;
        }

        Node current = node;
        while (current != null) {
            if (current instanceof Pane pane) {
                return pane;
            }
            current = current.getParent();
        }

        if (node.getScene() != null && node.getScene().getRoot() instanceof Pane sceneRootPane) {
            return sceneRootPane;
        }
        return null;
    }

    public static void setTheme(Parent root){
        themeToggle.getInstance().setTheme(root,"/CSS/lightMode.css","/CSS/darkMode.css");
    }

    public static void changeTheme(){
        themeToggle.getInstance().toggleTheme();
    }

    public static String hashPassword(String password){
        return passwordCrafting.hashPassword(password);
    }

    public static boolean checkPassword(String inputPassword, String realPassword){
        return passwordCrafting.checkPassword(inputPassword,realPassword);
    }

    public static void switchNewScene(Button clickButton, String fxmlName){
        switchPage.switchScene(clickButton, fxmlName);
    }

    public static StackPane findTabLoadPane(Node anyNodeInThatTab) {
        if (anyNodeInThatTab == null) return null;

        // ✅ First try: walk up the node hierarchy to find a per-tab property.
        // This avoids cross-tab bugs when multiple sideBarPane.fxml instances share the same Scene.
        Node current = anyNodeInThatTab;
        while (current != null) {
            Object p = current.getProperties().get("TAB_LOAD_PANE");
            if (p instanceof StackPane sp) return sp;
            current = current.getParent();
        }

        // Fallback: scene root (kept for backward compatibility)
        if (anyNodeInThatTab.getScene() == null) return null;
        Object p = anyNodeInThatTab.getScene().getRoot().getProperties().get("TAB_LOAD_PANE");
        return (p instanceof StackPane sp) ? sp : null;
    }


    public static void openFxml(String fxml,Node node){
        StackPane loadPane = findTabLoadPane(node);
        if (loadPane == null) return;
        switchPage.getInstance(loadPane).openFxml(fxml);
    }

    /**
     * Backward-compatible API.
     *
     * IMPORTANT: Some controllers call this during their initialize(). At that moment,
     * a loadPane-aware injection may not have happened yet (because FXMLLoader runs
     * controller.initialize() during load()). In those cases, loadPane can be null.
     */
    public static void showProjectCards(ObservableList<projects> projects, VBox containerPane, StackPane loadPane){
        if (loadPane == null) {
            // Try best-effort discovery from any node we already have.
            StackPane discovered = findTabLoadPane(containerPane);
            if (discovered == null) return;
            loadPane = discovered;
        }
        switchPage.getInstance(loadPane).loadProjects(projects, containerPane);
    }

    /**
     * Preferred API: derive the correct per-tab loadPane from any node inside the tab.
     */
    public static void showProjectCards(ObservableList<projects> projects, VBox containerPane, Node anyNodeInThatTab){
        StackPane loadPane = findTabLoadPane(anyNodeInThatTab);
        if (loadPane == null) return;
        switchPage.getInstance(loadPane).loadProjects(projects, containerPane);
    }

    public static void openProjectDetails(projects project,StackPane a){
        if (a == null) return;
        switchPage.getInstance(a).openProjectDetails(project);
    }


    public static void openWorkItemDetails(workItems items, projects project, Node anyNodeInThatTab){
        StackPane lp = findTabLoadPane(anyNodeInThatTab);
        if (lp == null) return;
        switchPage.getInstance(lp).openWorkItemDetails(items, project);
    }

    public static void viewUserInfo(users user, StackPane loadPane){
        if (loadPane == null) return;
        switchPage.getInstance(loadPane).viewUsersInfo(user);
    }

    public static void viewUserInfo(users user, Node anyNodeInThatTab){
        StackPane lp = findTabLoadPane(anyNodeInThatTab);
        if (lp == null) return;
        switchPage.getInstance(lp).viewUsersInfo(user);
    }

    public static Double durationFormat(Double duration, enumDuration durationStatus){return durationHelper.durationAssign(duration,durationStatus);}

    public static HashMap<enumDuration,Double> getDuration(Double duration){return durationHelper.showDuration(duration);}

    public static String generateProjectId(int projectId){
        String result = "PRJ-";
        if (projectId >99){
            result += projectId;
        }else if(projectId >9){
            result += "0"+projectId;
        }else {
            result += "00"+projectId;
        }
        return result;
    }

    public static void durationShowHelper(Double project,ComboBox<enumDuration> durationBox,TextField durationTxt){
        durationHelper.durationAssignHelper(project,durationBox,durationTxt);
    }

    public static String getOnlyOneDuration(Double duration,enumDuration durationType){
        if (durationType.equals(enumDuration.MONTH)) return durationHelper.showMonthDuration(duration);
        else if (durationType.equals(enumDuration.DAY)) return durationHelper.showDayDuration(duration);
        else return durationHelper.showYearDuration(duration);
    }

    public static String dateFormat(Date date){return dateFormatter.formatDate(date);}

    public static LocalDate toLocalDate(java.sql.Date date){return  dateFormatter.getLocalDate(date);}

    public static FontIcon iconSet(FontAwesomeSolid glyph){
        FontIcon icon = new FontIcon(glyph);
        icon.setIconSize(18);
        icon.getStyleClass().add("icon-Style");
        return icon;
    }

    // ==============================
    // Compact number / money format
    // Examples: 999 -> 999 MMK, 1_000 -> 1K MMK, 1_000_000 -> 1M MMK
    // Rounding rule: 10.0 -> 10, 10.9 -> 11
    // ==============================
    public static String formatCompactMoneyMMK(double value) {
        return formatCompactMoney(value, "MMK");
    }

    public static String formatCompactMoney(double value, String unit) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return "-";
        if (value <= 0) return "-";

        double abs = Math.abs(value);
        double scaled = value;
        String suffix = "";

        if (abs >= 1_000_000_000d) {
            scaled = value / 1_000_000_000d;
            suffix = "B";
        } else if (abs >= 1_000_000d) {
            scaled = value / 1_000_000d;
            suffix = "M";
        } else if (abs >= 1_000d) {
            scaled = value / 1_000d;
            suffix = "K";
        }

        long rounded = Math.round(scaled);
        String core = rounded + suffix;

        if (unit == null || unit.isBlank()) return core;
        return core + " " + unit;
    }

    // ==============================
// Duration rounding (days)
// Examples: 10.09 -> 10, 10.6 -> 11
// ==============================
    public static long roundDays(double days) {
        if (Double.isNaN(days) || Double.isInfinite(days)) return 0;
        return Math.round(days);
    }


    public static void applyStatusPill(Label lbl, String statusRaw) {
        if (lbl == null) return;

        // remove old status classes (keeps your other classes if any)
        lbl.getStyleClass().removeAll(
                "status-pill", "status-pill-default",
                "status-pill-active", "status-pill-pending",
                "status-pill-completed", "status-pill-cancelled"
        );

        lbl.getStyleClass().add("status-pill");

        String s = (statusRaw == null) ? "" : statusRaw.trim().toLowerCase();

        // map your status text -> css class
        if (s.contains("active") || s.contains("in progress") || s.contains("ongoing")) {
            lbl.getStyleClass().add("status-pill-active");
        } else if (s.contains("pending") || s.contains("hold") || s.contains("waiting")) {
            lbl.getStyleClass().add("status-pill-pending");
        } else if (s.contains("complete") || s.contains("done") || s.contains("finished")) {
            lbl.getStyleClass().add("status-pill-completed");
        } else if (s.contains("cancel") || s.contains("reject") || s.contains("fail")) {
            lbl.getStyleClass().add("status-pill-cancelled");
        } else {
            lbl.getStyleClass().add("status-pill-default");
        }
    }


}